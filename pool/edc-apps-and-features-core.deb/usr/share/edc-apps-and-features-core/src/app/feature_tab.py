#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import tkinter as tk
import tkinter.ttk as ttk
from PIL import ImageTk, Image
import logging
from natsort import natsorted

from distutils.version import LooseVersion

import locale
import textwrap

import scrollable_frame

import post_process

import requests
import re

import os

CapVersion = _('OS version')
CapUpdate = _('OS update')
DescUpdate = _('You can use the Update button to update to the latest OS. \
It will take some time to update the OS.')

class FeatureTab(tk.Frame):
    def __init__(self, master=None, info=None):
        super().__init__(master)
        self.master = master
        self.app_info_table = []
        self.os_info = info
        self.os_release = info['release']
        self.os_build = info['build']
        #self.init_status = []

    def get(self):
        logging.debug('FeaTab data')

    def show(self):
        frame = tk.Frame(self.master, relief=tk.FLAT, width=640, height=50)
        head1 = tk.Label(frame, text=CapVersion, font=('',14))
        # Set Text Frame
        self.os_info = _('Release:') + '\t' + self.os_release + '\n' + \
                       _('Build:') + '\t' + self.os_build
        disc1 = tk.Label(frame, text=self.os_info, 
                          wraplength=340, justify='left', font=('',10))
        head2 = tk.Label(frame, text=CapUpdate, font=('',14))
        disc2 = tk.Label(frame, text=DescUpdate, font=('',10), wraplength=340)
        button = tk.Button(frame, text=_('Upgrade'), command=self.upgrade)

        # label1.place(anchor=tk.W)
        # label2.place(anchor=tk.CENTER)
        # label3.place(anchor=tk.W)
        # button.place(anchor=tk.CENTER)

        head1.pack(padx=10, pady=5, anchor=tk.W)
        disc1.pack(padx=10, pady=5, anchor=tk.W)
        head2.pack(padx=10, pady=5, anchor=tk.W)
        disc2.pack(padx=10, pady=5, anchor=tk.W)
        button.pack(padx=10, pady=5)#, anchor=tk.CENTER)

        frame.pack()

    # obj,rev: [major, minnor, revision, model]
    def _is_version_ge(self, obj, ref):
        # check each version
        for i in range(4):
            if obj[i] < ref[i]:
                return False
            if obj[i] > ref[i]:
                return True
        return True

    # obj,rev: [major, minnor, revision, model]
    def _is_version_eq(self, obj, ref):
        # check each version
        for i in range(4):
            if not obj[i] == ref[i]:
                return False
        return True

    def _is_target_driver(self, driver, os):
        drvVer = [0] * 4
        osVer = [0] * 4
        drv = driver.split('-')
        drvRel = drv[1].split('.')
        drvBld = drv[-1].split('.')[0]
        for i in range(3):
            drvVer[i] = int(drvRel[i])
            osVer[i] = int(os[i])
        #drvVer[3] = int(drvBld)
        #osVer[3] = int(os[3])
        return self._is_version_eq(drvVer, osVer)

    def upgrade(self):
        res = tk.messagebox.askquestion('Upgrade', 'Do you want to continue?')
        if res == 'yes':
            stdout = post_process.apt_update()
            logging.debug(stdout)
            stdout = post_process.apt_fullupgrade()
            logging.debug(stdout)

            # get release version from /lib/modules/
            # search release version from drv and get wifi driver
            stdout = post_process._exec_s(['ls', '/lib/modules/'])
            versions = stdout.split('\n')
            versions = [ v for v in versions if '-v7+' in v ]
            versions = [ v for v in versions if v.split('-v7+')[0] ]
            versions = [ v for v in versions if '-' in v ]
            versions = [ v.split('-')[0] for v in versions ]
            versions = natsorted(versions)
            tv = versions[-1] # target version
            # print(versions[-1])
            os = tv.split('.')

            wifi_driver_url = "http://downloads.fars-robotics.net/wifi-drivers/8188eu-drivers/"
            response = requests.get(wifi_driver_url)
            drv = re.findall('href="8188eu.*?.gz"', response.text)
            drv = [ re.findall('(?<=").+?(?=")', l)[0] for l in drv ]
            drv = [ l for l in drv if '-v7-' in l ]
            drv = [ l for l in drv if self._is_target_driver(l, os) ]
            if len(drv) == 0:
                print('Error')
            if len(drv) > 1:
                drv = natsorted(drv)
            # print(drv)

            # stdout = post_process._exec_s(['whoami'])
            # print(stdout)
            curr = os.getcwd()
            os.chdir('/tmp')
            stdout = post_process._exec_s(['wget', wifi_driver_url+drv[0]])
            stdout = post_process._exec_s(['tar', 'xzf', drv[0]])
            stdout = post_process._exec_s(['./install.sh'])
            os.chdir(curr)

