#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import subprocess
import logging

LOCAL="/tmp/edc-apps-and-features/"
HOST="https://artec-kk.github.io/educom/"
#HOST="http://localhost/educon/"


# do command and return stdout by string.
def _exec_s(cmd_list):
    out = subprocess.run(cmd_list, stdout=subprocess.PIPE)
    return (out.stdout).decode('utf-8')

# req argument fomat
# {
#     'Package': 'Package name',
#     'Filename': 'File name',
#     'Request': 'Install/Uninstall/Updata/Maintain'
# },
def update(a):
    if (a['Request'] == 'Install' or a['Request'] == 'Update'):
        filename = a['Filename'].split('/')[-1]
        logging.debug(filename)
        # wget & install
        stdout = _exec_s(['wget', '-O', LOCAL+filename, HOST+a['Filename']])
        logging.debug(stdout)
        stdout = _exec_s(['sudo', 'apt', 'install', LOCAL+filename, '-y'])
        logging.debug(stdout)
    if a['Request'] == 'Uninstall':
        # remove
        stdout = _exec_s(['sudo', 'apt', 'remove', a['Package'], '-y'])
        logging.debug(stdout)

def apt_update():
    stdout = _exec_s(['sudo', 'apt', 'update'])
    logging.debug(stdout)

def apt_fullupgrade():
    stdout = _exec_s(['sudo', 'apt', 'full-upgrade', '-y'])
    logging.debug(stdout)

