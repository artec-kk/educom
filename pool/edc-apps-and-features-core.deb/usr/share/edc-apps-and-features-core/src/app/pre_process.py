#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import subprocess
import re
import json
from distutils.version import LooseVersion

import logging

# do command and return stdout by string.
def _exec_s(cmd_list):
    out = subprocess.run(cmd_list, stdout=subprocess.PIPE)
    return (out.stdout).decode('utf-8')

# Get package index file and return the dictionary of package distributed.
# return below list fomat
# [{
#   'Package': 'Package name',
#   'Description': 'Package description',
#   'LatestVer': 'Latest version'
# },{...}]
def _collect_package(package_index_file):
    contents = ''
    with open(package_index_file,'r') as f:
        contents = f.read()

    # Devide by 'Package:'
    contents = contents.split('Package:')
    tmep = contents
    contents = []
    for c in tmep:
        if c:
            contents.append('Package:' + c)

    # Extract package name, version and description
    dic = {}    # {'n':['v', 'd']}
    for c in contents:
        n = re.findall('Package:(.*)\n', c)[0]
        n = n.strip()
        v = re.findall('Version:(.*)\n', c)[0]
        v = v.strip()
        d = c.split('Description:')[1]
        d = d.strip()
        f = re.findall('Filename:(.*)\n', c)[0]
        f = f.strip()

        if n in dic:
            if (LooseVersion(dic[n][0])) < LooseVersion(v):
                dic[n] = [v,d,f]
        else:
            dic[n] = [v,d,f]

    packages = []
    for key, value in dic.items():
        pack = {}
        pack['Package'] = key
        pack['LatestVer'] = value[0]
        pack['Description'] = value[1]
        pack['Filename'] = value[2]
        packages.append(pack)

    return packages
 
# Get the list of package and return the list of package installed
def _installed_version(p):
    inst_pack = _exec_s(['dpkg', '-l'])
    inst_pack = inst_pack.split('\n')
    version = -1
    for ip in inst_pack:
        if p in ip:
            info = ip.split()
            version = info[2]
            break
    return version

# Get package and return the information of package installed 
def _get_package_infomation_(pack):
    pack_info = []
    inst_path = _exec_s(['dpkg', '-L', pack])
    inst_path = inst_path.split('\n')
    # Create entry
    for file in inst_path:
        # Get tile and information
        if '.desktop' in file:
            dot_desktop = _exec_s(['cat', file])
            entries = dot_desktop.split('[Desktop Entry]\n')
            entries.pop(0)  # delete empty
            for entry in entries:
                info = {}
                line = entry.split('\n')
                for l in line:
                    if ('Name' in l) or ('Comment' in l) or \
                       ('Icon' in l):
                        key, value = l.split('=')
                        info[key] = value
                pack_info.append(info)

    return pack_info

# Get package and return the information of package installed 
def _get_package_infomation(pack):
    pack_info = []
    jsn = open('../../data/data.json', 'r')
    dic_array = json.load(jsn)
    for dic in dic_array:
        if dic['Package'] == pack:
            for i in dic['info']:
                info = {}
                for k, v in i.items():
                    if ('Name' in k) or ('Comment' in k) or \
                       ('Icon' in k):
                        info[k] = v
                #print(info)                    
                pack_info.append(info)
    return pack_info

# return below list fomat
# [{
#   'Package': 'Package name',
#   'Description': 'Package description',
#   'LatestVer': 'Latest version'
#   'Name': 'Application name if installed',
#   'Comment': 'Application description if installed',
#   'Icon': 'Icone name if installed',
#   'Install': bool,
#   'InstallVersion': 'Install version' or '',
# }]
def get_package_info(package_index_file):
    # get package information from index file.
    distribution_package = _collect_package(package_index_file)

    logging.debug(distribution_package)

    packages = []
    # get installed/uninstalled from package name.
    for pack in distribution_package:
        info = pack
        ver = _installed_version(pack['Package'])
        if ver == -1:
            info['Install'] = False
            info['InstallVersion'] = ''
        else:
            info['Install'] = True
            info['InstallVersion'] = ver
        packages.append(info)

    prev_packages_info = packages
    packages = []

    # get package information supported this appli
    for pack in prev_packages_info:
        # if not installed then no information
        entries = _get_package_infomation(pack['Package'])
        if entries:
            # case: 1 package has multi desktop entry
            for entry in entries:
                entry.update(pack)
                packages.append(entry)
    return packages

def get_OS_info():
    os_info = []
    name = _exec_s(['lsb_release', '-a'])
    """
    name = name.split('\n')
    name = name[0].split(':')
    os_info.append(name[1].split()[0])
    version = _exec_s(['uname', '-v'])

    print(version)

    os_info.append(version.split('\n')[0])

    return os_info
    """
    return name


if __name__ == '__main__':
    package_index_file = '/tmp/edc-apps-and-features/Packages'
    get_package_info(package_index_file)
