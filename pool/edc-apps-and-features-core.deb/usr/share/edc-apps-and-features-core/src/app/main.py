#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# For Translation
import bootstrap
bootstrap.init_translation()

import logging

logging.basicConfig(level=logging.DEBUG, 
                    format='%(levelname)s: %(message)s')
# comment out below to see the debug log
#logging.disable(logging.CRITICAL)

import sys
import os
import tkinter as tk

import gui

import pre_process
import post_process
import progress_dlg

import threading
import time

logging.debug(sys.argv[1])

package_index_file = sys.argv[1]
#package_index_file = '/tmp/edc-apps-and-features/Packages'
package = pre_process.get_package_info(package_index_file)
os_info = pre_process.get_OS_info()

root = tk.Tk()
root.title(_('eduCom apprications and features'))

window_width = 640
window_height = 430
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight() - 100
x_cordinate = int((screen_width/2) - (window_width/2))
y_cordinate = int((screen_height/2) - (window_height/2))
root.geometry("{}x{}+{}+{}".
    format(window_width, window_height, x_cordinate, y_cordinate))

f_main = tk.Frame(root, width=630, height=100,
                  relief=tk.RIDGE, padx=0.5, pady=0.5)
note = gui.AppsAndFreatures(root, package, os_info)

note.pack()
f_main.pack()

package_processing = ''
package_request = ''
# req argument fomat
# [
#     # application
#     [
#         {
#             'Package': 'Package name',
#             'Filename': 'File name',
#             'Request': 'Install/Uninstall/Updata/Maintain'
#         },
#         {...}
#     ],
#     # feature
#     []
#  ]
def update_process(req):
    global package_processing, package_request
    app = req[0]
    for a in app:
        package_processing = a['Package']
        package_request = a['Request']
        # time.sleep(3)
        logging.debug(a)
        post_process.update(a)
    
    progress_dialog.setMessage(_('Update finished'))

def close_window():
    root.destroy()

def check_update_progress():
    if update_thread.is_alive():
        root.after(20, check_update_progress)
        progress_dialog.setMessage(
            package_processing + '\n' + package_request)
    else:
        time.sleep(2)
        progress_dialog.stop()
        root.destroy()

def ok_pressed():
    global update_thread, progress_dialog

    req = note.get()

    progress_dialog = progress_dlg.InfoDialog(root, _("Start pdate..."))
    update_thread = threading.Thread(target=update_process, args=(req,))
    update_thread.deamon = True
    progress_dialog.start()
    update_thread.start()
    root.after(20, check_update_progress)

def tab_changed(event):
    note = event.widget
    select_tab = note.tab(note.select(), "text")
    logging.debug(select_tab)
    if (select_tab == _('Applications')):
        f_main.pack()
    if (select_tab == _('Features')):
        f_main.pack_forget()


note.bind("<<NotebookTabChanged>>", tab_changed)

tk.Button(f_main, text=_('OK'), font=('',14), 
          command=ok_pressed).pack(side=tk.LEFT)
tk.Button(f_main, text=_('CANCEL'), 
          command=close_window, font=('',14)).pack(side=tk.LEFT)

root.mainloop()
