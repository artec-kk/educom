#!/bin/bash
path_conf=/etc/hostapd/edu-cam

if [ "$1" == "" ]; then
  # No password specified.
  exit 1
fi
pass=$1

sudo sed -i -e "s/wpa_passphrase=\(.*\)/wpa_passphrase=$pass/" $path_conf

if [ -e /var/lock/subsys/edu-cam ]; then
  sudo ifdown wlan0
  sudo ifup wlan0
fi
