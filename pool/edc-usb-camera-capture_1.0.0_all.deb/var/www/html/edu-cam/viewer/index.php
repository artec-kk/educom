<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>USBカメラキャプチャー ビュワー</title>
    <style>
        #container {
            display: flex;
            flex-direction: row;
        }

        #wrapper_stream {
            position: relative;
            height: 84vh;
        }

        #main_img {
            /* height: 100%; */
            width: 62vw;
            z-index: 1;
        }

        #ss_img {
            position: absolute;
            /* height: 100%; */
            width: 62vw;
            top: 0;
            left: 0;
            z-index: 2;
        }

        #snapshot {
            margin-left: 1rem;
            height: 95vh;
            overflow-y: scroll;
            display: flex;
            flex-direction: column;
        }

        #snapshot img {
            height: 18vh;
            padding: 5px;
        }
    </style>
</head>

<body>
    <div id="container">
        <div id="wrapper_stream">
            <div id="header">USBカメラキャプチャー ビュワー</div>
            <img id="main_img" src="http://<?php echo $_SERVER['SERVER_NAME']; ?>:8080/?action=stream"></img>
            <!-- Debug -->
            <!-- <img id="main_img" src="./images/sample.png"></img> -->
            <img id="ss_img" src="../images/input.png"></img>
        </div>
        <div id="snapshot">
            <div id="00">
                <img src="" />
                <div class="date"></div>
            </div>
            <div id="01">
                <img src="" />
                <div class="date"></div>
            </div>
            <div id="02">
                <img src="" />
                <div class="date"></div>
            </div>
            <div id="03">
                <img src="" />
                <div class="date"></div>
            </div>
            <div id="04">
                <img src="" />
                <div class="date"></div>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="draw.js"></script>
    <script>
        const periodicalFunc = () => {
            return setInterval(() => {
                reloadImage();
                loadSS();
            }, 1000);
        }
        let id = periodicalFunc();

        window.addEventListener('DOMContentLoaded', function() {
            // ページの表示状態が変わったときに実行
            document.addEventListener("visibilitychange", function() {
                console.log(document.visibilityState);
                if(id) {
                    clearInterval(id);
                    id = null;
                } else {
                    id = periodicalFunc();
                }
            });
        });

        const h = document.getElementById("header").clientHeight;
        document.getElementById("ss_img").setAttribute("style", `top: ${h}px;`);
    </script>
</body>

</html>