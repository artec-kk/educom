#!/bin/bash
DIR=$(cd $(dirname $0); pwd)
inputFile=input.png
pre=/tmp/tmp-pre.jpg
post=/tmp/tmp-post.jpg
target=$DIR/$inputFile
output=$DIR/ss0$1.jpg
LOCK=/var/lock/edu-cam-conv

if [ -e $LOCK ]; then
  echo IN_PROCESS
  exit 1;
fi
touch $LOCK

curl http://localhost:8080/?action=snapshot --output $pre
size=`identify -format '%wx%h' $target`
convert $pre -resize $size $post
if [ "$2" == "pen" ]; then
  composite $target $post $output
else
  cp $post $output
fi

rm /var/lock/edu-cam-conv
