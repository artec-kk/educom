#!/bin/bash
existance=`v4l2-ctl --list-devices 2>&1 1> /dev/null`
if [ ! "$existance" = "" -a -e /var/edu-cam/pid_streaming ]; then
  kill -9 `cat /var/edu-cam/pid_streaming`
  rm -rf /etc/cron.d/edu-cam
fi
