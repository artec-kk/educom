#!/bin/bash
PORT="8080"
ID="edu"
PW="edu"

#SIZE="320x240"
#SIZE="640x480"
#SIZE="1280x960"
#SIZE="1920x1080"
SIZE="3840x2160"

#FRAMERATE="40"
FRAMERATE="10"
#FRAMERATE="1"

QUAL=10
DELAY=0.05

LD_LIBRARY_PATH=/usr/local/lib

DIR=/etc/edu-cam/streaming/mjpg-streamer
cd $DIR

if [ "$1" == "multi" ]; then
    # File input
    exec ./mjpg_streamer -i "input_file.so -f /var/www/html/edu-cam/images/ss -d $DELAY" -o "output_http.so -w ./www -p $PORT"
else
    # UVC
    # Checking the video device existance because of being used by mjpg-streamer.
    videoExistance=`ls /dev/video0 2> /dev/null`
    if [ "$videoExistance" == "" ]; then
        exit 1
    fi
    exec $DIR/mjpg_streamer -i "$DIR/input_uvc.so -f $FRAMERATE -r $SIZE -d /dev/video0 -q $QUAL -n" -o "$DIR/output_http.so -w ./www -p $PORT"
fi
