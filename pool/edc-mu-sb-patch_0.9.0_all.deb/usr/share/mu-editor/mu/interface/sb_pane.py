"""
Contains the UI classes used to populate the various panes used by Mu.

Copyright (c) 2015-2017 Nicholas H.Tollervey and others (see the AUTHORS file).

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import os
import re
import logging
import os.path
from PyQt5.QtCore import (Qt, QProcessEnvironment, pyqtSignal, QTimer)
from PyQt5.QtWidgets import (QMessageBox, QFrame, QListWidget,
                             QGridLayout, QLabel, QMenu, QDockWidget,
                             QTreeWidget, QTreeWidgetItem)
from PyQt5.QtGui import QTextCursor
from mu.interface.themes import Font
from mu.interface.themes import DEFAULT_FONT_SIZE

logger = logging.getLogger(__name__)

from mu.interface.panes import MicroPythonREPLPane, LocalFileList

PANE_ZOOM_SIZES = {
    'xs': 8,
    's': 10,
    'm': 14,
    'l': 16,
    'xl': 18,
    'xxl': 24,
    'xxxl': 28,
}


class StuduinoBitLocalFileList(LocalFileList):
    """
    Override dropEvent method for drag and drop between QListWidget
    and QTreeWidget.
    """

    def dropEvent(self, event):
        source = event.source()

        if source.currentItem().childCount() != 0:
            self.set_message.emit(_("File only"))
            return

        if isinstance(source, MicroPythonDeviceFileTree):
            file_exists = self.findItems(
                source.currentItem().text(0), Qt.MatchExactly
            )
            if (
                not file_exists
                or file_exists
                and self.show_confirm_overwrite_dialog()
            ):
                self.disable.emit()

                # Make source path
                src_path = []
                src = source.currentItem()
                while src.parent() is not None:
                    src = src.parent()
                    src_path.insert(0, src.text(0))

                src_path = "/".join(src_path)

                studuinobit_path_filename = (
                    src_path + "/" + source.currentItem().text(0)
                )
                studuinobit_filename = source.currentItem().text(0)
                local_filename = os.path.join(self.home, studuinobit_filename)
                msg = _(
                    "Getting '{}' from studuino:bit. " "Copying to '{}'."
                ).format(studuinobit_path_filename, local_filename)
                logger.info(msg)
                self.set_message.emit(msg)
                self.get.emit(studuinobit_path_filename, local_filename)


class MuFileTree(QTreeWidget):
    """
    Contains shared methods for the two types of file listing used in Mu.
    """

    disable = pyqtSignal()
    list_files = pyqtSignal()
    set_message = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.setHeaderHidden(True)

    def show_confirm_overwrite_dialog(self):
        """
        Display a dialog to check if an existing file should be overwritten.

        Returns a boolean indication of the user's decision.
        """
        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Information)
        msg.setText(_("File already exists; overwrite it?"))
        msg.setWindowTitle(_("File already exists"))
        msg.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
        return msg.exec_() == QMessageBox.Ok

class MicroPythonDeviceFileTree(MuFileTree):
    """
    Represents a tree of files on a MicroPython device.
    """

    put = pyqtSignal(str, str)
    delete = pyqtSignal(str)

    def __init__(self, home):
        super().__init__()
        self.home = home
        self.setDragDropMode(QListWidget.DragDrop)

    def dropEvent(self, event):
        source = event.source()
        if isinstance(source, LocalFileList):
            # Make drop path
            drop_path = []

            target = self.itemAt(event.pos())

            target_item = None
            if target is not None:
                if target.childCount() != 0:
                    drop_path.insert(0, target.text(0))
                    if target_item is None:
                        target_item = target
                while target.parent() is not None:
                    target = target.parent()
                    drop_path.insert(0, target.text(0))
                    if target_item is None:
                        target_item = target

            target_path = "/".join(drop_path)

            # Check file exist
            file_exists = False
            if target_item is None:
                file_exists = self.findItems(
                    source.currentItem().text(), Qt.MatchExactly
                )
            else:
                for i in range(target_item.childCount()):
                    if source.currentItem().text() == target_item.child(
                        i
                    ).text(0):
                        file_exists = True

            # Copy file
            if (not file_exists) or (
                file_exists and self.show_confirm_overwrite_dialog()
            ):
                self.disable.emit()
                local_filename = os.path.join(
                    self.home, source.currentItem().text()
                )

                msg = _("Copying '{}' to device.").format(local_filename)
                logger.info(msg)
                self.set_message.emit(msg)
                self.put.emit(local_filename, target_path)

    def on_put(self, device_file):
        """
        Fired when the put event is completed for the given filename.
        """
        self.list_files.emit()
        # msg = _("'{}' successfully copied to device.").format(device_file)
        # self.set_message.emit(msg)

    def contextMenuEvent(self, event):
        menu = QMenu(self)
        delete_action = menu.addAction(_("Delete (cannot be undone)"))
        action = menu.exec_(self.mapToGlobal(event.pos()))
        if action == delete_action:

            # device_filename = self.currentItem().text(0)
            # Make drop path
            drop_path = []
            target = self.currentItem()
            filename = target.text(0)
            if target.childCount() != 0:
                self.set_message.emit(_("Can't delete folder."))
                return

            self.disable.emit()
            while target.parent() is not None:
                target = target.parent()
                drop_path.insert(0, target.text(0))
            target_path = "/".join(drop_path)
            device_filename = target_path + "/" + filename

            logger.info("Deleting {}".format(device_filename))
            msg = _("Deleting '{}' from device.").format(device_filename)
            logger.info(msg)
            self.set_message.emit(msg)
            self.delete.emit(device_filename)

    def on_delete(self, device_file):
        """
        Fired when the delete event is completed for the given filename.
        """
        self.list_files.emit()
        # msg = _("'{}' successfully deleted from device.").format(device_file)
        # self.set_message.emit(msg)


class StuduinoBitREPLPane(MicroPythonREPLPane):
    """
    Override 'process_bytes' method to make countermeasure utf-8 and
    Studuino:bit's serial transfer feature (divided transfer of ESC, CSI)
    """

    def __init__(self, serial, theme="day", parent=None):
        super().__init__(serial, theme, parent)
        self.prev_data = []
        self.utf8data = []

    def process_bytes(self, data):
        """
        Given some incoming bytes of data, work out how to handle / display
        them in the REPL widget.
        """
        # If data is included ESC or CSI
        if len(self.prev_data) != 0:
            self.prev_data += data
            data = self.prev_data
            self.prev_data = []

        tc = self.textCursor()
        # The text cursor must be on the last line of the document. If it isn't
        # then move it there.
        while tc.movePosition(QTextCursor.Down):
            pass
        i = 0
        while i < len(data):
            # print(data[i], end=", ")

            if data[i] == 8:  # \b
                tc.movePosition(QTextCursor.Left)
                self.setTextCursor(tc)
            elif data[i] == 13:  # \r
                pass
            elif len(data) == i + 1 and data[i] == 27:  # ESC
                # If data is less ESC data
                self.prev_data = data[i:]
                return

            elif (
                len(data) > i + 1 and data[i] == 27 and data[i + 1] == 91
            ):  # CSI
                csi_top = i
                # VT100 cursor detected: <Esc>[
                i += 2  # move index to after the [
                regex = r"(?P<count>[\d]*)(;?[\d]*)*(?P<action>[ABCDKm])"
                m = re.search(regex, data[i:].decode("utf-8"))
                if m:
                    # move to (almost) after control seq
                    # (will ++ at end of loop)
                    i += m.end() - 1

                    if m.group("count") == "":
                        count = 1
                    else:
                        count = int(m.group("count"))

                    if m.group("action") == "A":  # up
                        tc.movePosition(QTextCursor.Up, n=count)
                        self.setTextCursor(tc)
                    elif m.group("action") == "B":  # down
                        tc.movePosition(QTextCursor.Down, n=count)
                        self.setTextCursor(tc)
                    elif m.group("action") == "C":  # right
                        tc.movePosition(QTextCursor.Right, n=count)
                        self.setTextCursor(tc)
                    elif m.group("action") == "D":  # left
                        tc.movePosition(QTextCursor.Left, n=count)
                        self.setTextCursor(tc)
                    elif m.group("action") == "K":  # delete things
                        if m.group("count") == "":  # delete to end of line
                            tc.movePosition(
                                QTextCursor.EndOfLine,
                                mode=QTextCursor.KeepAnchor,
                            )
                            tc.removeSelectedText()
                            self.setTextCursor(tc)
                    elif m.group("action") == "m":  # SGR
                        pass
                    # else:
                    #     self.prev_data = data[csi_top:]
                    #     return
                else:
                    self.prev_data = data[csi_top:]
                    return
            elif data[i] == 10:  # \n
                tc.movePosition(QTextCursor.End)
                self.setTextCursor(tc)
                self.insertPlainText(chr(data[i]))
            else:
                if (
                    data[i] >= 0xE0 and data[i] <= 0xEF
                ) or self.utf8data != []:
                    self.utf8data.append(data[i])
                    if len(self.utf8data) == 3:
                        tc.deleteChar()
                        self.setTextCursor(tc)
                        try:
                            self.insertPlainText(
                                bytes(self.utf8data).decode("utf-8")
                            )
                        except UnicodeDecodeError as e:
                            logger.info("Unicode Decode error:", e)
                        self.utf8data = []
                else:
                    tc.deleteChar()
                    self.setTextCursor(tc)
                    self.insertPlainText(chr(data[i]))
            i += 1
        self.ensureCursorVisible()

    def send_commands(self, commands):
        """
        Send commands to the REPL via raw mode.
        """
        raw_on = [  # Sequence of commands to get into raw mode.
            b"\x02",
            b"\r\x03",
            b"\r\x03",
            b"\r\x03",
            b"\r\x01",
        ]
        newline = [b'print("\\n")\r']
        commands = [c.encode("utf-8") + b"\r" for c in commands]
        commands.append(b"\r")
        commands.append(b"\x04")
        raw_off = [b"\x02"]
        command_sequence = raw_on + newline + commands + raw_off
        self.execute(command_sequence)

    def execute(self, commands):
        """
        Execute a series of commands over a period of time (scheduling
        remaining commands to be run in the next iteration of the event loop).
        """
        if commands:
            command = commands[0]
            logger.info("Sending command {}".format(command))
            self.serial.write(command)
            remainder = commands[1:]
            remaining_task = lambda commands=remainder: self.execute(commands)
            QTimer.singleShot(10, remaining_task)


class StuduinoBitFileSystemPane(QFrame):
    """
    Contains two QListWidgets representing the Studuino:bit and the user's
    code directory. Users transfer files by dragging and dropping.
    Highlighted files can be selected for deletion.
    """

    set_message = pyqtSignal(str)
    set_warning = pyqtSignal(str)
    list_files = pyqtSignal()
    open_file = pyqtSignal(str)

    def __init__(self, home):
        super().__init__()
        self.home = home
        self.font = Font().load()
        studuinobit_fs = MicroPythonDeviceFileTree(home)
        local_fs = StuduinoBitLocalFileList(home)

        @local_fs.open_file.connect
        def on_open_file(file):
            # Bubble the signal up
            self.open_file.emit(file)

        layout = QGridLayout()
        self.setLayout(layout)
        studuinobit_label = QLabel()
        studuinobit_label.setText(_("Files on your device:"))
        local_label = QLabel()
        local_label.setText(_("Files on educom:"))
        self.studuinobit_label = studuinobit_label
        self.local_label = local_label
        self.studuinobit_fs = studuinobit_fs
        self.local_fs = local_fs
        self.set_font_size()
        layout.addWidget(studuinobit_label, 0, 0)
        layout.addWidget(local_label, 0, 1)
        layout.addWidget(studuinobit_fs, 1, 0)
        layout.addWidget(local_fs, 1, 1)
        self.studuinobit_fs.disable.connect(self.disable)
        self.studuinobit_fs.set_message.connect(self.show_message)
        self.local_fs.disable.connect(self.disable)
        self.local_fs.set_message.connect(self.show_message)

    def disable(self):
        """
        Stops interaction with the list widgets.
        """
        self.studuinobit_fs.setDisabled(True)
        self.local_fs.setDisabled(True)
        self.studuinobit_fs.setAcceptDrops(False)
        self.local_fs.setAcceptDrops(False)

    def enable(self):
        """
        Allows interaction with the list widgets.
        """
        self.studuinobit_fs.setDisabled(False)
        self.local_fs.setDisabled(False)
        self.studuinobit_fs.setAcceptDrops(True)
        self.local_fs.setAcceptDrops(True)

    def show_message(self, message):
        """
        Emits the set_message signal.
        """
        self.set_message.emit(message)

    def show_warning(self, message):
        """
        Emits the set_warning signal.
        """
        self.set_warning.emit(message)

    def on_tree(self, studuinobit_files):
        """
        Displays a tree of the files on the Studuino:bit.

        Since tree of files is always the final event in any interaction
        between Mu and the Studuino:bit, this enables the controls again
        for further interactions to take place.
        """
        self.studuinobit_fs.clear()
        self.local_fs.clear()

        items = []
        for item in studuinobit_files:
            item_parts = item.split("/")
            item_parts.pop(0)

            entry = QTreeWidgetItem(None, [item_parts[0]])
            items_text = [i.text(0) for i in items]
            if entry.text(0) not in items_text:
                parent_item = entry
            else:
                parent_index = items_text.index(entry.text(0))
                parent_item = items[parent_index]

            if len(item_parts) > 1:
                for i in item_parts[1:]:
                    child_item = QTreeWidgetItem(None, [i])
                    child_list_text = [
                        parent_item.child(i).text(0)
                        for i in range(parent_item.childCount())
                    ]

                    if child_item.text(0) in child_list_text:
                        child_index = child_list_text.index(child_item.text(0))
                        parent_item = parent_item.child(child_index)
                    else:
                        parent_item.addChild(child_item)
                        parent_item = child_item

            items.append(entry) if entry.text(0) not in items_text else None

        self.studuinobit_fs.addTopLevelItems(items)

        local_files = [
            f
            for f in os.listdir(self.home)
            if os.path.isfile(os.path.join(self.home, f))
        ]
        local_files.sort()
        for f in local_files:
            self.local_fs.addItem(f)
        self.enable()

    def on_tree_fail(self):
        """
        Fired when tree of  files fails.
        """
        self.show_warning(
            _(
                "There was a problem getting the list of files on "
                "the device. Please check Mu's logs for "
                "technical information. Alternatively, try "
                "unplugging/plugging-in your device and/or "
                "restarting Mu."
            )
        )
        self.disable()

    def on_put_fail(self, filename):
        """
        Fired when the referenced file cannot be copied onto the device.
        """
        self.show_warning(
            _(
                "There was a problem copying the file '{}' onto "
                "the device. Please check Mu's logs for "
                "more information."
            ).format(filename)
        )

    def on_delete_fail(self, filename):
        """
        Fired when a deletion on the device for the given file failed.
        """
        self.show_warning(
            _(
                "There was a problem deleting '{}' from the "
                "device. Please check Mu's logs for "
                "more information."
            ).format(filename)
        )

    def on_get_fail(self, filename):
        """
        Fired when getting the referenced file on the device failed.
        """
        self.show_warning(
            _(
                "There was a problem getting '{}' from the "
                "device. Please check Mu's logs for "
                "more information."
            ).format(filename)
        )

    def set_theme(self, theme):
        pass

    def set_font_size(self, new_size=DEFAULT_FONT_SIZE):
        """
        Sets the font size for all the textual elements in this pane.
        """
        self.font.setPointSize(new_size)
        self.studuinobit_label.setFont(self.font)
        self.local_label.setFont(self.font)
        self.studuinobit_fs.setFont(self.font)
        self.local_fs.setFont(self.font)

    def set_zoom(self, size):
        """
        Set the current zoom level given the "t-shirt" size.
        """
        self.set_font_size(PANE_ZOOM_SIZES[size])


class StuduinoBitREPLPane(MicroPythonREPLPane):
    """
    Override 'process_bytes' method to make countermeasure utf-8 and
    Studuino:bit's serial transfer feature (divided transfer of ESC, CSI)
    """

    def __init__(self, serial, theme="day", parent=None):
        super().__init__(serial, theme, parent)
        self.prev_data = []
        self.utf8data = []

    def process_bytes(self, data):
        """
        Given some incoming bytes of data, work out how to handle / display
        them in the REPL widget.
        """
        # If data is included ESC or CSI
        if len(self.prev_data) != 0:
            self.prev_data += data
            data = self.prev_data
            self.prev_data = []

        tc = self.textCursor()
        # The text cursor must be on the last line of the document. If it isn't
        # then move it there.
        while tc.movePosition(QTextCursor.Down):
            pass
        i = 0
        while i < len(data):
            # print(data[i], end=", ")

            if data[i] == 8:  # \b
                tc.movePosition(QTextCursor.Left)
                self.setTextCursor(tc)
            elif data[i] == 13:  # \r
                pass
            elif len(data) == i + 1 and data[i] == 27:  # ESC
                # If data is less ESC data
                self.prev_data = data[i:]
                return

            elif (
                len(data) > i + 1 and data[i] == 27 and data[i + 1] == 91
            ):  # CSI
                csi_top = i
                # VT100 cursor detected: <Esc>[
                i += 2  # move index to after the [
                regex = r"(?P<count>[\d]*)(;?[\d]*)*(?P<action>[ABCDKm])"
                m = re.search(regex, data[i:].decode("utf-8"))
                if m:
                    # move to (almost) after control seq
                    # (will ++ at end of loop)
                    i += m.end() - 1

                    if m.group("count") == "":
                        count = 1
                    else:
                        count = int(m.group("count"))

                    if m.group("action") == "A":  # up
                        tc.movePosition(QTextCursor.Up, n=count)
                        self.setTextCursor(tc)
                    elif m.group("action") == "B":  # down
                        tc.movePosition(QTextCursor.Down, n=count)
                        self.setTextCursor(tc)
                    elif m.group("action") == "C":  # right
                        tc.movePosition(QTextCursor.Right, n=count)
                        self.setTextCursor(tc)
                    elif m.group("action") == "D":  # left
                        tc.movePosition(QTextCursor.Left, n=count)
                        self.setTextCursor(tc)
                    elif m.group("action") == "K":  # delete things
                        if m.group("count") == "":  # delete to end of line
                            tc.movePosition(
                                QTextCursor.EndOfLine,
                                mode=QTextCursor.KeepAnchor,
                            )
                            tc.removeSelectedText()
                            self.setTextCursor(tc)
                    elif m.group("action") == "m":  # SGR
                        pass
                    # else:
                    #     self.prev_data = data[csi_top:]
                    #     return
                else:
                    self.prev_data = data[csi_top:]
                    return
            elif data[i] == 10:  # \n
                tc.movePosition(QTextCursor.End)
                self.setTextCursor(tc)
                self.insertPlainText(chr(data[i]))
            else:
                if (
                    data[i] >= 0xE0 and data[i] <= 0xEF
                ) or self.utf8data != []:
                    self.utf8data.append(data[i])
                    if len(self.utf8data) == 3:
                        tc.deleteChar()
                        self.setTextCursor(tc)
                        try:
                            self.insertPlainText(
                                bytes(self.utf8data).decode("utf-8")
                            )
                        except UnicodeDecodeError as e:
                            logger.info("Unicode Decode error:", e)
                        self.utf8data = []
                else:
                    tc.deleteChar()
                    self.setTextCursor(tc)
                    self.insertPlainText(chr(data[i]))
            i += 1
        self.ensureCursorVisible()

    def send_commands(self, commands):
        """
        Send commands to the REPL via raw mode.
        """
        raw_on = [  # Sequence of commands to get into raw mode.
            b"\x02",
            b"\r\x03",
            b"\r\x03",
            b"\r\x03",
            b"\r\x01",
        ]
        newline = [b'print("\\n")\r']
        commands = [c.encode("utf-8") + b"\r" for c in commands]
        commands.append(b"\r")
        commands.append(b"\x04")
        raw_off = [b"\x02"]
        command_sequence = raw_on + newline + commands + raw_off
        self.execute(command_sequence)

    def execute(self, commands):
        """
        Execute a series of commands over a period of time (scheduling
        remaining commands to be run in the next iteration of the event loop).
        """
        if commands:
            command = commands[0]
            logger.info("Sending command {}".format(command))
            self.serial.write(command)
            remainder = commands[1:]
            remaining_task = lambda commands=remainder: self.execute(commands)
            QTimer.singleShot(10, remaining_task)


class StuduinoBitFileSystemPane(QFrame):
    """
    Contains two QListWidgets representing the Studuino:bit and the user's
    code directory. Users transfer files by dragging and dropping.
    Highlighted files can be selected for deletion.
    """

    set_message = pyqtSignal(str)
    set_warning = pyqtSignal(str)
    list_files = pyqtSignal()
    open_file = pyqtSignal(str)

    def __init__(self, home):
        super().__init__()
        self.home = home
        self.font = Font().load()
        studuinobit_fs = MicroPythonDeviceFileTree(home)
        local_fs = StuduinoBitLocalFileList(home)

        @local_fs.open_file.connect
        def on_open_file(file):
            # Bubble the signal up
            self.open_file.emit(file)

        layout = QGridLayout()
        self.setLayout(layout)
        studuinobit_label = QLabel()
        studuinobit_label.setText(_("Files on your device:"))
        local_label = QLabel()
        local_label.setText(_("Files on educom:"))
        self.studuinobit_label = studuinobit_label
        self.local_label = local_label
        self.studuinobit_fs = studuinobit_fs
        self.local_fs = local_fs
        self.set_font_size()
        layout.addWidget(studuinobit_label, 0, 0)
        layout.addWidget(local_label, 0, 1)
        layout.addWidget(studuinobit_fs, 1, 0)
        layout.addWidget(local_fs, 1, 1)
        self.studuinobit_fs.disable.connect(self.disable)
        self.studuinobit_fs.set_message.connect(self.show_message)
        self.local_fs.disable.connect(self.disable)
        self.local_fs.set_message.connect(self.show_message)

    def disable(self):
        """
        Stops interaction with the list widgets.
        """
        self.studuinobit_fs.setDisabled(True)
        self.local_fs.setDisabled(True)
        self.studuinobit_fs.setAcceptDrops(False)
        self.local_fs.setAcceptDrops(False)

    def enable(self):
        """
        Allows interaction with the list widgets.
        """
        self.studuinobit_fs.setDisabled(False)
        self.local_fs.setDisabled(False)
        self.studuinobit_fs.setAcceptDrops(True)
        self.local_fs.setAcceptDrops(True)

    def show_message(self, message):
        """
        Emits the set_message signal.
        """
        self.set_message.emit(message)

    def show_warning(self, message):
        """
        Emits the set_warning signal.
        """
        self.set_warning.emit(message)

    def on_tree(self, studuinobit_files):
        """
        Displays a tree of the files on the Studuino:bit.

        Since tree of files is always the final event in any interaction
        between Mu and the Studuino:bit, this enables the controls again
        for further interactions to take place.
        """
        self.studuinobit_fs.clear()
        self.local_fs.clear()

        items = []
        for item in studuinobit_files:
            item_parts = item.split("/")
            item_parts.pop(0)

            entry = QTreeWidgetItem(None, [item_parts[0]])
            items_text = [i.text(0) for i in items]
            if entry.text(0) not in items_text:
                parent_item = entry
            else:
                parent_index = items_text.index(entry.text(0))
                parent_item = items[parent_index]

            if len(item_parts) > 1:
                for i in item_parts[1:]:
                    child_item = QTreeWidgetItem(None, [i])
                    child_list_text = [
                        parent_item.child(i).text(0)
                        for i in range(parent_item.childCount())
                    ]

                    if child_item.text(0) in child_list_text:
                        child_index = child_list_text.index(child_item.text(0))
                        parent_item = parent_item.child(child_index)
                    else:
                        parent_item.addChild(child_item)
                        parent_item = child_item

            items.append(entry) if entry.text(0) not in items_text else None

        self.studuinobit_fs.addTopLevelItems(items)

        local_files = [
            f
            for f in os.listdir(self.home)
            if os.path.isfile(os.path.join(self.home, f))
        ]
        local_files.sort()
        for f in local_files:
            self.local_fs.addItem(f)
        self.enable()

    def on_tree_fail(self):
        """
        Fired when tree of  files fails.
        """
        self.show_warning(
            _(
                "There was a problem getting the list of files on "
                "the device. Please check Mu's logs for "
                "technical information. Alternatively, try "
                "unplugging/plugging-in your device and/or "
                "restarting Mu."
            )
        )
        self.disable()

    def on_put_fail(self, filename):
        """
        Fired when the referenced file cannot be copied onto the device.
        """
        self.show_warning(
            _(
                "There was a problem copying the file '{}' onto "
                "the device. Please check Mu's logs for "
                "more information."
            ).format(filename)
        )

    def on_delete_fail(self, filename):
        """
        Fired when a deletion on the device for the given file failed.
        """
        self.show_warning(
            _(
                "There was a problem deleting '{}' from the "
                "device. Please check Mu's logs for "
                "more information."
            ).format(filename)
        )

    def on_get_fail(self, filename):
        """
        Fired when getting the referenced file on the device failed.
        """
        self.show_warning(
            _(
                "There was a problem getting '{}' from the "
                "device. Please check Mu's logs for "
                "more information."
            ).format(filename)
        )

    def set_theme(self, theme):
        pass

    def set_font_size(self, new_size=DEFAULT_FONT_SIZE):
        """
        Sets the font size for all the textual elements in this pane.
        """
        self.font.setPointSize(new_size)
        self.studuinobit_label.setFont(self.font)
        self.local_label.setFont(self.font)
        self.studuinobit_fs.setFont(self.font)
        self.local_fs.setFont(self.font)

    def set_zoom(self, size):
        """
        Set the current zoom level given the "t-shirt" size.
        """
        self.set_font_size(PANE_ZOOM_SIZES[size])


def add_studuinobit_filesystem(self, home, file_manager):
    """
    Adds Studuino:bit file system pane to the application.
    """
    self.fs_pane = StuduinoBitFileSystemPane(home)

    @self.fs_pane.open_file.connect
    def on_open_file(file):
        # Bubble the signal up
        self.open_file.emit(file)

    self.fs = QDockWidget(_("Filesystem on ") + _("Studuino:bit"))
    self.fs.setWidget(self.fs_pane)
    self.fs.setFeatures(QDockWidget.DockWidgetMovable)
    self.fs.setAllowedAreas(Qt.BottomDockWidgetArea)
    self.addDockWidget(Qt.BottomDockWidgetArea, self.fs)
    self.fs_pane.setFocus()
    file_manager.on_list_files.connect(self.fs_pane.on_tree)
    self.fs_pane.list_files.connect(file_manager.tree)
    self.fs_pane.studuinobit_fs.put.connect(file_manager.put)
    self.fs_pane.studuinobit_fs.delete.connect(file_manager.delete)
    self.fs_pane.studuinobit_fs.list_files.connect(file_manager.tree)
    self.fs_pane.local_fs.get.connect(file_manager.get)
    self.fs_pane.local_fs.list_files.connect(file_manager.tree)
    file_manager.on_put_file.connect(self.fs_pane.studuinobit_fs.on_put)
    file_manager.on_delete_file.connect(
        self.fs_pane.studuinobit_fs.on_delete
    )
    file_manager.on_get_file.connect(self.fs_pane.local_fs.on_get)
    file_manager.on_list_fail.connect(self.fs_pane.on_tree_fail)
    file_manager.on_put_fail.connect(self.fs_pane.on_put_fail)
    file_manager.on_delete_fail.connect(self.fs_pane.on_delete_fail)
    file_manager.on_get_fail.connect(self.fs_pane.on_get_fail)
    self.connect_zoom(self.fs_pane)
    return self.fs_pane

def add_studuionbit_repl(self, port, name, force_interrupt=True):
    """
    Adds a MicroPython based REPL pane to the application.
    """
    if not self.serial:
        self.open_serial_link(port)
        if force_interrupt:
            # Send a Control-B / exit raw mode.
            self.serial.write(b"\x02")
            # Send a Control-C / keyboard interrupt.
            self.serial.write(b"\x03")
    repl_pane = StuduinoBitREPLPane(serial=self.serial)
    self.data_received.connect(repl_pane.process_bytes)
    self.add_repl(repl_pane, name)
