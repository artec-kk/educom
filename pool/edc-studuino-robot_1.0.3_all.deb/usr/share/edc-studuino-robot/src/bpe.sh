#!/bin/bash

## Checking if Arduino IDE is installed.
if [ ! `which arduino` ]; then
echo 'Arduino IDE was not found. Please install it.'
zenity --warning --text="Please install Arduino IDE first.\n\n  sudo apt-get update\n  sudo apt-get install arduino" 2> /dev/null
exit 1
fi

# For porting to Linux from Widows environment.
# set directories 
BPE_DIR=/usr/share/edc-studuino-robot/src/studuinoBPE
sudo chmod 666 "$BPE_DIR/Board.cfg"
sudo chmod 666 "$BPE_DIR/Block.ini"
sudo chmod 666 "$BPE_DIR/portNumber.info"
sudo chmod 777 "$BPE_DIR/user"
sudo chmod 777 "$BPE_DIR"

COMMON_DIR=/usr/share/edc-studuino-robot/src/common
sudo chmod 666 "$COMMON_DIR/dc_calib_ini"
sudo chmod 666 "$COMMON_DIR/dc_calib_ini_imm"
sudo chmod 666 "$COMMON_DIR/sv_offset.ini"
sudo chmod 666 "$COMMON_DIR/sv_offset_ini"
sudo chmod 777 "$COMMON_DIR/tools/build"
sudo rm "$COMMON_DIR/tools/build/artecRobot.cpp.d"
sudo rm "$COMMON_DIR/tools/build/artecRobot.cpp.eep"
sudo rm "$COMMON_DIR/tools/build/artecRobot.cpp.elf"
sudo rm "$COMMON_DIR/tools/build/artecRobot.cpp.hex"
sudo rm "$COMMON_DIR/tools/build/artecRobot.cpp.o"

### Change directory which has this shell script.
cd `dirname $0`
cd ./studuinoBPE
### Run Board manager by background process.
java -jar ./BoardManager.jar &
BM_ID1=$!
### Run Block programming environment.
#if [ -e /usr/bin/squeak.old ]; then
../squeak.old ./StuduinoBPE.image
#else
#squeak ./StuduinoBPE.image
#fi

### kill Board manager process
sudo kill $BM_ID1
