#!/usr/bin/env python3
#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import smbus
import time
from key_stroke import keypress, up, down, left, right, reset_u, reset_d, reset_l, reset_r
from analogstick_server import server_start
import threading
import js_values

ADDR_PIC = 0x09
EXT_PAD_X = 3
EXT_PAD_Y = 4

i2c_PIC = smbus.SMBus(11)

# 0000:none, 0001:up, 0010:down, 0100:left, 1000:right
key_status = 0b0000

def reset_other():
    temp = key_status
    if temp and 0b0001 != 0:
        keypress(reset_u)
    if temp and 0b0010 != 0:
        keypress(reset_d)
    if temp and 0b0100 != 0:
        keypress(reset_l)
    if temp and 0b1000 != 0:
        keypress(reset_r)

handle_thread = threading.Thread(target=server_start, args=(),daemon=True)
handle_thread.start()

while True:
    padX = i2c_PIC.read_byte_data(ADDR_PIC, EXT_PAD_X)
    padY = i2c_PIC.read_byte_data(ADDR_PIC, EXT_PAD_Y)

    js_values.LOCK.acquire()
    js_values.PAD_X = padX
    js_values.PAD_Y = padY
    # print('{0}, {1}'.format(PAD_X, PAD_Y))
    js_values.LOCK.release()

    time.sleep(0.01)

    # print('ks:' + str(key_status))
    if padY > 160:
        if (key_status & 0b0001) == 0:
            reset_other();
            key_status = key_status | 0b0001
            keypress(up)
    elif padY < 80:
        if (key_status & 0b0010) == 0:
            reset_other();
            key_status = key_status | 0b0010
            keypress(down)
    else:
        if (key_status & 0b0001) != 0:
            key_status = key_status & 0b1110
            keypress(reset_u)
        if (key_status & 0b0010) != 0:
            key_status = key_status & 0b1101
            keypress(reset_d)
        # print('y:' + str(key_status))

    if padX > 160:
        if (key_status & 0b0100) == 0:
            reset_other();
            key_status = key_status | 0b0100
            keypress(left)
    elif padX < 80:
        if (key_status & 0b1000) == 0:
            reset_other();
            key_status = key_status | 0b1000
            keypress(right)
    else:
        if (key_status & 0b0100) != 0:
            key_status = key_status & 0b1011
            keypress(reset_l)
        if (key_status & 0b1000) != 0:
            key_status = key_status & 0b0111
            keypress(reset_r)    
        # print('x:' + str(key_status))
