#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
 
import socket
import threading
import time
import js_values
 
HOST = ''
PORT = 9998
clients = []
 
 
def remove_conection(con, address):
    """クライアントと接続を切る"""
 
    print('[切断]{}'.format(address))
    con.close()
    clients.remove((con, address))
 
 
def server_start():
    """サーバをスタートする"""
 
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind((HOST, PORT))
    sock.listen(10)
 
    while True:
        con, address = sock.accept()
        print("[接続]{}".format(address))
        clients.append((con, address))
        handle_thread = threading.Thread(target=handler,
                                         args=(con, address),
                                         daemon=True)
        handle_thread.start()
 
 
def handler(con, address):
    """クライアントからデータを受信する"""
    x = 0
    y = 0
    while True:
        time.sleep(0.01)
        try:
            js_values.LOCK.acquire()
            curx = js_values.PAD_X
            cury = js_values.PAD_Y
            js_values.LOCK.release()

            if (x != curx) or (y != cury):
                x = curx
                y = cury

                clients[0][0].send((str(x) + ',' + str(y) + ';').encode())
                # print(str(x) + ',' + str(y) + ';')

        except ConnectionResetError:
            remove_conection(con, address)
            break
        except BrokenPipeError:
            remove_conection(con, address)
            break


if __name__ == "__main__":
    server_start()