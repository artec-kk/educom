#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import shutil
import re

file_name = '/boot/config.txt'
# file_name = '/home/pi/config.txt'    # Test

def get():
    global file_name

    with open(file_name) as f:
        s = f.read()

    config_init = []

    config_l = re.search('(.*)dtparam=joystick\n', s)
    l_mouse_used = (config_l.group(1) == '#')
    config_init.append(l_mouse_used)
    
    config_r = re.search('dtparam=gpio_south_btn=0x110\n', s)
    if not(config_r == None):
        r_mouse_used = True
        config_init.append(r_mouse_used)
    else:
        r_mouse_used = False
        b = re.search('dtparam=gpio_north_btn=(.*)\n', s)
        b1 = b.group(1)
        b = re.search('dtparam=gpio_east_btn=(.*)\n', s)
        b2 = b.group(1)
        b = re.search('dtparam=gpio_west_btn=(.*)\n', s)
        b3 = b.group(1)
        b = re.search('dtparam=gpio_south_btn=(.*)\n', s)
        b4 = b.group(1)
        config_init.append(r_mouse_used)
        config_init.append(b1)
        config_init.append(b2)
        config_init.append(b3)
        config_init.append(b4)
    return config_init

def set(r, c, l):
    global file_name
    
    back_name = file_name + '.bak'
    shutil.copy(file_name, back_name)
    
    with open(file_name) as f:
        s = f.read()

    co = re.search('(.*)dtparam=joystick\n', s)
    is_co = (co.group(1) == '#')
    if r == 0 and not(is_co):
        s = re.sub('dtparam=joystick\n', '#dtparam=joystick\n', s)
    if r == 1 and is_co:
        s = re.sub('#dtparam=joystick\n', 'dtparam=joystick\n', s)
    
    if c['cb'] == 1:
        pass

    if l['sel'] == 1:
        ln = 'dtparam=gpio_north_btn=' + str(l['b1']) + '\n'
        s = re.sub('dtparam=gpio_north_btn=(.*)\n', ln, s)
        le = 'dtparam=gpio_east_btn=' + str(l['b2']) + '\n'
        s = re.sub('dtparam=gpio_east_btn=(.*)\n', le, s)
        lw = 'dtparam=gpio_west_btn=' + str(l['b3']) + '\n'
        s = re.sub('dtparam=gpio_west_btn=(.*)\n', lw, s)
        ls = 'dtparam=gpio_south_btn=' + str(l['b4']) + '\n'
        s = re.sub('dtparam=gpio_south_btn=(.*)\n', ls, s)
    else:
        ln = 'dtparam=gpio_north_btn=0x112\n'
        s = re.sub('dtparam=gpio_north_btn=(.*)\n', ln, s)
        le = 'dtparam=gpio_east_btn=0x111\n'
        s = re.sub('dtparam=gpio_east_btn=(.*)\n', le, s)
        lw = 'dtparam=gpio_west_btn=0x113\n'
        s = re.sub('dtparam=gpio_west_btn=(.*)\n', lw, s)
        ls = 'dtparam=gpio_south_btn=0x110\n'
        s = re.sub('dtparam=gpio_south_btn=(.*)\n', ls, s)

    with open(file_name, mode='w') as f:
        f.write(s)
