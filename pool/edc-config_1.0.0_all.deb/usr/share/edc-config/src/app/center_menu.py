#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import tkinter as tk
from const import BW, FONT
from touchpen_calibration import TouchPanelCalibration

import logging

class CenterMenu:
    CALIBV=[0, 0, 0, 0]	# MIN_X, MAX_X, MIN_Y, MAX_Y
    def __init__(self, master=None):

        self.tp_calib_panel = TouchPanelCalibration(master)

        self.data = {'changed': False, 'min_x': 0, 'min_y': 0, 'max_x': 0, 'max_y': 0}

        CA_W = 240
        CA_H = 180
        self.frame = tk.Frame(master, width=CA_W, height=CA_H,
                              relief=tk.RIDGE, bd=3)

        self.label_title = tk.Label(self.frame, font=FONT, text=_('Stylus Calibration'),
                                    wraplength=CA_W-5)
        self.label_title.place(anchor=tk.N, relx=0.5)
        self.label_title.bind('<ButtonPress-1>', self.get_cursor_pos) # 1 -> left button 

        self.label_msg = tk.Label(self.frame, font=('', 12), text=_('Touch here!'),
                                  wraplength=CA_W-5)
        self.label_msg.place(anchor=tk.CENTER, relx=0.5, rely=0.5)
        self.label_msg.bind('<ButtonPress-1>', self.get_cursor_pos) # 1 -> left button 

        self.frame.pack()
        self.frame.bind('<ButtonPress-1>', self.get_cursor_pos) # 1 -> left button
        self.frame.place(anchor=tk.CENTER, relx=0.5, rely=0.5)

    def get_cursor_pos(self, event):
        self.tp_calib_panel.openDialog(self.cb_getV)

    def get(self):
        return self.data
    
    def cb_getV(self, *ret):
        rv = ret[0]
        if rv is None:
            pass
        else:
            self.data['changed'] = True
            self.data['min_x'] = rv['min_x']
            self.data['max_x'] = rv['max_x']
            self.data['min_y'] = rv['min_y']
            self.data['max_y'] = rv['max_y']
