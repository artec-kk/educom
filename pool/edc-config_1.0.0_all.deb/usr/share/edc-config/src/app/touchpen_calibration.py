#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import tkinter as tk
import subprocess
import statistics
import threading
import numpy as np
from const import BW, FONT
import time

import logging


class TouchPanelCalibration:
    def __init__(self, master=None):
        self.parent = master
        self.dialog = None
        self.var = tk.IntVar()
        self.result = {'min_x': 0, 'min_y': 0, 'max_x': 0, 'max_y': 0}
        self.width = 1024
        self.height = 600
        self.p1x = int(self.width*0.1)
        self.p1y = int(self.height*0.1)
        self.p2x = int(self.width*0.5)
        self.p2y = int(self.height*0.9)
        self.p3x = int(self.width*0.9)
        self.p3y = int(self.height*0.5)
        self.p1xv = 585
        self.p1yv = 650
        self.p2xv = 2000
        self.p2yv = 3000
        self.p3xv = 3450
        self.p3yv = 1800
        self.tar_margin = 50

    def openDialog(self, callback):
        self.dialog = tk.Toplevel(self.parent)
        self.dialog.geometry("{0}x{1}+0+0".format(self.width, self.height))
        self.dialog.config(cursor='none')
        self.dialog.overrideredirect(1)
        self.dialog.wait_visibility()
        self.dialog.grab_set()

        self.cb = callback

        self.vx = []
        self.vy = []
        self.datax = []
        self.datay = []
        self.target_area = {'xmin': 0, 'xmax': 0, 'ymin': 0, 'ymax': 0}
        self.measure_complete = False
        self.process_status = 0
        self.is_hold = False

        CA_W = 40
        CA_H = CA_W
        LN_W = 8
        self.ca_w = CA_W 
        self.ca_h = CA_W
        self.ln_w = LN_W

        self.ca1 = tk.Canvas(self.dialog, width=CA_W, height=CA_H,
                             bd=0, highlightthickness=0, relief='ridge')
        self.drawTarget(self.ca1, CA_W, CA_H, LN_W, 'black')
        #self.ca1.bind('<ButtonPress-1>', self.get_cursor_pos) # 1 -> left button
        #self.ca1.bind('<ButtonRelease-1>', self.rel_cursor) # 1 -> left button
        self.message = tk.StringVar()
        self.label = tk.Label(self.dialog, font=FONT, 
                              textvariable=self.message,
                              justify='left'
                             ).place(anchor=tk.CENTER, 
                                     relx=0.5, rely=0.5)
        tk.Button(self.dialog, text=_('Close'), 
                  #command=self.close_window, font=FONT
                  font=FONT
                 ).place(anchor=tk.CENTER, relx=0.5, rely=0.6)


        self.setTargetPos(self.process_status)
        thread1 = threading.Thread(target=self.touchChecker)
        thread1.setDaemon(True)
        thread1.start()

    def drawTarget(self, ca, ca_w, ca_h, w, col):
        ca.create_line(0, ca_h/2, ca_w, ca_h/2, width=w, fill=col) # X axis
        ca.create_line(ca_w/2, 0, ca_w/2, ca_h, width=w, fill=col) # Y axis
        
    def touchChecker(self):
        self.t = threading.Timer(0.1, self.touchChecker)
        if self.dialog is None:
            return
        else:
            self.t.start()

        # get touch position to x and y
        xy = self.getTouchPosXY()
        if xy is None:
            return
        vx = xy[0]
        vy = xy[1]
        logging.debug(">>>>>>>{0},{1}".format(vx, vy))

        # return button area
        if (vx > 1900 and vx < 2100) and (vy > 2000 and vy < 2200):
            self.close_window()

        if self.measure_complete:
            return

        # target area
        if not ((vx > self.target_area['xmin'] and vx < self.target_area['xmax']) and \
                (vy > self.target_area['ymin'] and vy < self.target_area['ymax'])):
            return

        self.drawTarget(self.ca1, self.ca_w, self.ca_h, self.ln_w, 'white')

        self.vx.append(vx)
        self.vy.append(vy)
        if len(self.vx) == 6:
            # check x and y position validation and return True/False
            if self.touchValidation():
                # add x and y position to self.datax and self.datay
                self.setTouchPos()
                self.postProcess()
            self.vx = []
            self.vy = []

    def getTouchPanelADC(self):
        args = ['i2cdump', '-y', '-r', '0x08-0x0d', '11', '9']
        cp = subprocess.run(args, stdout=subprocess.PIPE)
        str = (cp.stdout).decode('utf-8')
        ltok = str.split('\n')
        ltok = ltok[1].split()
        sx = ltok[2] + ltok[1]
        sy = ltok[4] + ltok[3]
        sz = ltok[6] + ltok[5]
        nx = int(sx, 16)
        ny = int(sy, 16)
        nz = int(sz, 16)
        return nx, ny, nz

    # append vx and vy when touch the panel
    def getTouchPosXY(self):
        self.drawTarget(self.ca1, self.ca_w, self.ca_h, self.ln_w, 'black')
        vx, vy, vz = self.getTouchPanelADC()
        #logging.debug("+++{0},{1},{2}".format(vx, vy,vz))
        if vz > 3800:   # release status
            self.is_hold = False
            return None
        if self.is_hold:
            return None

        self.is_hold = True

        return vx, vy


    # check validation touch position x and y
    def touchValidation(self):
        logging.debug("touchValidation")
        x = statistics.pstdev(self.vx)
        y = statistics.pstdev(self.vy)
        if x < 10 and y < 10:
            return True
        else:
            return False
        
    def setTouchPos(self):
        logging.debug("setTouchPos")
        self.datax.append(statistics.mean(self.vx))
        self.datay.append(statistics.mean(self.vy))

    def postProcess(self):
        logging.debug("postProcess")
        self.setTargetPos(self.process_status+1)
        self.process_status += 1


    def setTargetPos(self, status):
        if status == 0:
            self.message.set(_('Touch the center of the + at the top left several times.'))
            self.ca1.place(anchor=tk.CENTER, x=self.p1x, y=self.p1y)
            x = self.p1xv
            y = self.p1yv
            m = self.tar_margin
            self.target_area = {'xmin': x-m, 'xmax': x+m, 'ymin': y-m, 'ymax': y+m}
        elif status == 1:
            self.message.set(_('Touch the center of the + at the bottom several times.'))
            self.ca1.place(anchor=tk.CENTER, x=self.p2x, y=self.p2y)
            x = self.p2xv
            y = self.p2yv
            m = self.tar_margin
            self.target_area = {'xmin': x-m, 'xmax': x+m, 'ymin': y-m, 'ymax': y+m}
        elif status == 2:
            self.message.set(_('Touch the center of the + at the right several times.'))
            self.ca1.place(anchor=tk.CENTER, x=self.p3x, y=self.p3y)
            x = self.p3xv
            y = self.p3yv
            m = self.tar_margin
            self.target_area = {'xmin': x-m, 'xmax': x+m, 'ymin': y-m, 'ymax': y+m}
        elif status == 3:
            self.message.set(_('Finished!'))
            self.ca1.place_forget()
            # self.dialog.config(cursor='arrow')
            self.measure_complete = True
            
    def close_window(self):
        self.dialog.grab_release()
        self.dialog.withdraw()
        self.dialog = None

        if self.measure_complete:
            ## Voltage calculation of min/max of X and Y
            x = np.array([self.p1x, self.p2x, self.p3x])
            vx = np.array(self.datax)
            cfx = np.polyfit(x, vx, 1)
            y = np.array([self.p1y, self.p2y, self.p3y])
            vy = np.array(self.datay)
            cfy = np.polyfit(y, vy, 1)
            logging.debug('{0}, {1}, {2}'.format(x, vx, cfx))
            logging.debug('{0}, {1}, {2}'.format(y, vy, cfy))
            self.result['min_x'] = int(cfx[1])
            self.result['max_x'] = int(cfx[0] * self.width + cfx[1])
            self.result['min_y'] = int(cfy[1])
            self.result['max_y'] = int(cfy[0] * self.height + cfy[1])

            self.cb(self.result)
        else:
            self.cb(None)
        return "break"

