#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import tkinter as tk
import tkinter.ttk as ttk

# from PIL import Image, ImageTk
from const import BW, FONT

import key_allocation as ka

import logging


class RightMenu:
    def __init__(self, masterl, masterr, ini):
        self.data = {'sel': 0, 'b1': 0, 'b2': 0, 'b3': 0, 'b4': 0}

        f_set1_button = tk.Frame(masterl, width=120, height=120,
                                 relief=tk.RIDGE, bd=BW, bg='white')
        self.ca_button = [0] * 4
        for num in range(4):
            self.ca_button[num] = tk.Canvas(f_set1_button, width=42, height=42,
                                            relief=tk.RIDGE, bd=BW, bg='white',
                                            highlightthickness=0)
            self.ca_button[num].create_oval(1, 1, 40, 40, fill='gray') # Circle
            self.ca_button[num].create_text(20, 20, font=('', 14), text=str(num+1)) # Circle
            self.ca_button[num].bind('<ButtonRelease-1>', self.button_clicked) # 1 -> left button

        self.ca_button[0].place(anchor=tk.N, relx=0.5, rely=0.0)
        self.ca_button[1].place(anchor=tk.E, relx=1.0, rely=0.5)
        self.ca_button[2].place(anchor=tk.W, relx=0.0, rely=0.5)
        self.ca_button[3].place(anchor=tk.S, relx=0.5, rely=1.0)
        f_set1_button.place(anchor=tk.E, relx=0.97, rely=0.4)

        f_set1_r_radio = tk.Frame(masterl, width=140, height=65, relief=tk.RIDGE,
                                  bd=BW, bg='white')
        self.var = tk.IntVar()
        self.var.set(0)
        rb_m2 = tk.Radiobutton(f_set1_r_radio, value=0, font=FONT,
                               variable=self.var, text=_('Mouse'), bg='white',
                               highlightthickness=0)
        rb_kb = tk.Radiobutton(f_set1_r_radio, value=1, font=FONT,
                               variable=self.var, text=_('Keyboard'), bg='white',
                               highlightthickness=0)
        rb_m2.bind('<ButtonRelease-1>', self.check_changed) # 1 -> left button
        rb_kb.bind('<ButtonRelease-1>', self.check_changed) # 1 -> left button
        rb_m2.place(anchor=tk.NW, relx=0.0, rely=0.0)
        rb_kb.place(anchor=tk.SW, relx=0.0, rely=1.0)

        f_set1_r_radio.place(anchor=tk.SE, relx=0.97, rely=0.9)

        # f_setting3
        self.label = [0] * 4
        self.entry = [0] * 4
        self.comb_var = [0] * 4
        for num in range(4):
            self.comb_var[num] = tk.StringVar()
            f_entry = tk.Frame(masterr)
            f_entry.pack(pady=10)
            # Label
            self.label[num] = tk.Label(f_entry, font=FONT, text=str(num+1))
            self.label[num].pack(side='left', padx=10)
            self.label[num]['state'] = 'disable'
            # ComboBox
            self.entry[num] = ttk.Combobox(f_entry, textvariable=self.comb_var[num],
                                           value=list(ka.key_dict.keys()), font=FONT,
                                           justify='center', width=13)
            self.entry[num].pack(side='left')
            self.entry[num].current(0)
            self.entry[num]['state'] = 'disable'

        if not(ini[0]):    # not(is_mouse?)
            self.var.set(1)
            logging.debug(ini[1:])
            for i, ini_kv in enumerate(ini[1:5]):
                for j, kv in enumerate(ka.key_dict.values()):
                    if (kv == int(ini_kv)):
                        self.entry[i].current(j)
            self.check_changed(None)


    def check_changed(self, event):
        if (self.var.get() == 1):
            for num in range(4):
                self.ca_button[num].create_oval(1, 1, 40, 40, fill='white')
                self.ca_button[num].create_text(20, 20, font=('', 14), text=str(num+1)) # Circle
                self.label[num]['state'] = 'normal'
                self.entry[num]['state'] = 'normal'
        else:
            for num in range(4):
                self.ca_button[num].create_oval(1, 1, 40, 40, fill='gray')
                self.ca_button[num].create_text(20, 20, font=('', 14), text=str(num+1)) # Circle
                self.label[num]['state'] = 'disable'
                self.entry[num]['state'] = 'disable'

    def button_clicked(self, event):
        if (self.var.get() == 1):
            tk.messagebox.showinfo('', _('Assign a key to a button from the right list.'))

    def get(self):
        self.data['sel'] = self.var.get()
        self.data['b1'] = ka.key_dict[self.comb_var[0].get()]
        self.data['b2'] = ka.key_dict[self.comb_var[1].get()]
        self.data['b3'] = ka.key_dict[self.comb_var[2].get()]
        self.data['b4'] = ka.key_dict[self.comb_var[3].get()]
        
        return self.data
    