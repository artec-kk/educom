#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import tkinter as tk
import tkinter.ttk as ttk
from PIL import ImageTk, Image
import logging

from distutils.version import LooseVersion

import locale
import textwrap

import scrollable_frame


class AppTab(tk.Frame):
    def __init__(self, master=None, pack_info=None):
        super().__init__(master)
        self.master = master
        self.pack_info = pack_info
        self.app_info_table = []
        self.init_status = []

    def show(self):
        # header
        header = tk.Frame(self.master, relief=tk.FLAT,
                          width=640, height=50)
        header_icon = tk.Frame(header, bd=10, width=60, height=50)
        header_text = tk.Frame(header, bd=10, width=360, height=50)
        header_stat = tk.Frame(header, bd=10, width=130, height=50)
        header_upde = tk.Frame(header, bd=10, width=70, height=50)

        tk.Label(header_text, text=_('Application'),font=('',14))\
                              .place(anchor=tk.W, rely=0.5)
        tk.Label(header_stat, text=_('Install'),font=('',14))\
                              .place(anchor=tk.W, rely=0.5)
        tk.Label(header_upde, text=_('Update'),font=('',14))\
                              .place(anchor=tk.W, rely=0.5)
    
        header_icon.pack(side=tk.LEFT, anchor=tk.W)
        header_text.pack(side=tk.LEFT, anchor=tk.W)
        header_stat.pack(side=tk.LEFT, anchor=tk.W)
        header_upde.pack(side=tk.LEFT, anchor=tk.W)

        # body
        body = scrollable_frame.ScrollableFrame(
                self.master, bar_x=False, width=640, height=300)

        for pack in self.pack_info:
            info = self._get_package_info(pack)
            self.init_status.append(info)

            logging.debug('----')
            logging.debug(pack)
            logging.debug('----')

            appi = AppInfoFrame(body.scrollable_frame,
                     info['Icon'], info['Filename'], info['Package'],
                     info['Name'], info['Comment'],
                     info['Installed'], info['Updatable'])
            appi.pack()
            self.app_info_table.append(appi)

        header.pack()
        body.pack()

    def get_req(self):
        requests = []
        for item in self.app_info_table:
            requests.append(item.get_request())

        request_info = []
        logging.debug('Check start!')
        for i_item in self.init_status:
            for r in requests:
                if i_item['Package'] == r[0]:       # r[0]:package
                    if i_item['Installed'] == r[2]: # r[2]:Install/Uninstall
                        if r[3]:                    # r[3]:Update
                            request_info.append(
                                {'Filename': i_item['Filename'],
                                 'Package':  i_item['Package'],
                                 'Request': 'Update'})
                        else:
                            request_info.append(
                                {'Filename': i_item['Filename'],
                                 'Package':  i_item['Package'],
                                 'Request': 'Maintain'})
                    else:
                        if r[2]:
                            request_info.append(
                                {'Filename': i_item['Filename'],
                                 'Package':  i_item['Package'],
                                 'Request': 'Install'})
                        else:
                            request_info.append(
                                {'Filename': i_item['Filename'],
                                 'Package':  i_item['Package'],
                                 'Request': 'Uninstall'})

        return request_info

    def _get_package_info(self, pack):
        # {'Icon', 'Name', 'Comment', 'Installed', 'Updatable'}
        entry = {}
        # educon software
        # if pack.get('Install'): # Installed Package
        
        # Icon
        icon_path = ''
        icon = pack.get('Icon')
        if not icon is None:
            icon_path = '../../data/'+icon
        entry['Icon'] = icon_path

        # Filename
        name = pack.get('Filename')
        entry['Filename'] = name

        # Package
        name = pack.get('Package')
        entry['Package'] = name

        # Name
        l = locale.getlocale()[0]
        name = ''
        std = pack.get('Name')
        loc = pack.get('Name['+l[0:2]+']')
        if not loc is None:
            name = loc
        elif not std is None:
            name = std
        entry['Name'] = name

        # Comment
        comment = ''
        std = pack.get('Comment')
        loc = pack.get('Comment['+l[0:2]+']')
        if not loc is None:
            comment = loc
        elif not std is None:
            comment = std
        entry['Comment'] = comment

        # Installed
        installed = pack.get('Install')
        entry['Installed'] = installed

        # Updatable
        updatable = False
        if installed:
            cver = pack.get('InstallVersion')
            lver = pack.get('LatestVer')
            if (cver is None) or (lver is None):
                pass
            elif LooseVersion(cver) < LooseVersion(lver):
                updatable = True
        entry['Updatable'] = updatable

        return entry


class AppInfoFrame(tk.Frame):
    def __init__(self, parent, icon_path, fname, pname, name, comment, installed, updatable):
        super().__init__(parent, relief=tk.FLAT, width=640, height=100)

        self.pname = pname
        self.fname = fname

        icon_frame = tk.Frame(self, bd=10, width=60, height=100)
        text_frame = tk.Frame(self, bd=10, width=360, height=100)
        isnt_frame = tk.Frame(self, bd=10, width=100, height=100)
        upda_frame = tk.Frame(self, bd=10, width=100, height=100)

        # Set Icon Frame
        # create a canvas to show image on
        canvas_for_image = tk.Canvas(icon_frame, height=60,
                                     width=60, borderwidth=0,
                                     highlightthickness=0)
        canvas_for_image.grid(row=0, column=0, sticky='nesw',
                              padx=0, pady=0)
        # create image from image location resize it to 60X60 and put in on canvas
        if not icon_path is '':
            image = Image.open(icon_path)
            canvas_for_image.image = \
                ImageTk.PhotoImage(image.resize((60, 60),
                                   Image.ANTIALIAS))
            canvas_for_image.create_image(
                0, 0, image=canvas_for_image.image, anchor='nw')

        # Set Text Frame
        tk.Label(text_frame, text=name+'\n'+comment, wraplength=340,
                 justify='left', font=('',10)).place(anchor='nw')

        # Set Install Frame
        # create a checkbutton to install
        self.install_req = tk.BooleanVar()
        if installed:
            self.install_req.set(True)
        inst_button = tk.Checkbutton(isnt_frame, variable=self.install_req,
                                     command=self.change_install_state)
        inst_button.place(anchor=tk.CENTER, relx=0.5, rely=0.5)
 
        # Set Update Frame
        # create a checkbutton to update
        self.updatable = updatable
        self.update_req = tk.BooleanVar()
        self.upda_button = tk.Checkbutton(upda_frame, variable=self.update_req)
        self.upda_button.place(anchor=tk.CENTER, relx=0.5, rely=0.5)
        if not updatable:
            self.upda_button.config(state='disable')
            
        # Pack All Frame
        icon_frame.pack(side=tk.LEFT, anchor=tk.W)
        text_frame.pack(side=tk.LEFT, anchor=tk.W)
        isnt_frame.pack(side=tk.LEFT, anchor=tk.W)
        upda_frame.pack(side=tk.LEFT, anchor=tk.W)

        # self.pack()

    def change_install_state(self):
        if self.install_req.get():
            if self.updatable:
                self.upda_button.config(state='normal')
        else:
            self.upda_button.config(state='disable')

    # return Package, Filename, Install, UpdateRequest
    def get_request(self):
        return self.pname, self.fname, self.install_req.get(), self.update_req.get()
