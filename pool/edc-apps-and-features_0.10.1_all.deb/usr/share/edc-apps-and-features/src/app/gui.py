#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import tkinter as tk
import tkinter.ttk as ttk
from PIL import ImageTk, Image
import logging

from distutils.version import LooseVersion

import locale
import textwrap

import scrollable_frame
import feature_tab
import application_tab

class AppsAndFreatures(ttk.Notebook):
    def __init__(self, master=None, app_package=None, os_info=None):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('mystyle.TNotebook', relief="flat")
        style.configure('mystyle.TNotebook.Tab', font=('', 14))

        super().__init__(master, style='mystyle.TNotebook')

        app = tk.Frame(master, relief=tk.FLAT)
        self.add(app, text=_('Applications'))
        self.apptab = application_tab.AppTab(master=app,
                                             pack_info=app_package)
        self.apptab.show()

        fea = tk.Frame(master, relief=tk.FLAT)
        self.add(fea, text=_('Features'))
        self.featab = feature_tab.FeatureTab(master=fea,
                                             info=os_info)
        self.featab.show()

    def get(self):
        app_req = self.apptab.get_req()
        fea_req = self.featab.get()
        return [app_req, fea_req]
